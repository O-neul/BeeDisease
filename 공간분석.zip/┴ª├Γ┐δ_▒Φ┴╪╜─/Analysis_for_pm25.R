
##################################### Data loading #####################################
pm2.5 = read.csv('pm25.csv', header=T, stringsAsFactors=FALSE)
pm2.5 = pm2.5[1:217,c(3,10,11,12,13,14)]

energy = read.csv('Energy Use.csv', header=T)
energy = energy[1:217,c(3,10,11,12,13,14)]
energy$Country.Name == pm2.5$Country.Name
energy = energy[,-1]

fossil = read.csv('Fossil Fuel energy consumption.csv', header=T)
fossil = fossil[1:217,c(3,10,11,12,13,14)]

fossil$Country.Name == pm2.5$Country.Name
fossil = fossil[,-1]


renew = read.csv('Renewable Energy Consumption.csv', header=T)
renew = renew[1:217,c(3,10,11,12,13,14)]
renew$Country.Name == pm2.5$Country.Name
renew = renew[,-1]


urban = read.csv('Urban population.csv', header=T)
urban = urban[1:217,c(3,10,11,12,13,14)]
urban$Country.Name == pm2.5$Country.Name
urban = urban[,-1]

forest = read.csv('forest.csv', header=T)
head(forest)
tail(forest)
forest = forest[,c(1,25,26,27,28,29)]
forest$Country.Name = as.character(forest$Country.Name)
forest[192,]$Country.Name = "Korea, Dem. People\342\200\231s Rep."
forest = forest[(which(forest$Country.Name %in% pm2.5$Country.Name)),]
forest = forest[order(forest$Country.Name),]
colnames(forest) = c("Country.Name","forest2010","forest2011","forest2012","forest2013","forest2014")


colnames(pm2.5) = c("Country.Name", "y2010", "y2011", "y2012", "y2013", "y2014")
colnames(energy) = c("e2010", "e2011", "e2012", "e2013", "e2014")
colnames(fossil) = c("f2010", "f2011", "f2012", "f2013", "f2014")
colnames(renew) = c("r2010", "r2011", "r2012", "r2013", "r2014")
colnames(urban) = c("u2010", "u2011", "u2012", "u2013", "u2014")

pm2.5 = cbind(pm2.5, energy, fossil, renew, urban)

pm2.5 = merge(x=pm2.5, y=forest, key=Country.Name, all=TRUE)


site = read.csv('longitudelattitude.csv')

pm2.5$Country.Name[-which(pm2.5$Country.Name[1:217] %in% site$name)]
site$name
pm2.5$Country.Name[pm2.5$Country.Name == "Korea, Rep."] = "South Korea"
pm2.5$Country.Name[pm2.5$Country.Name == "Bahamas, The"] = "Bahamas"
pm2.5$Country.Name[pm2.5$Country.Name == "Yemen, Rep."] = "Yemen"
pm2.5$Country.Name[pm2.5$Country.Name == "Virgin Islands (U.S.)"] = "U.S. Virgin Islands"
pm2.5$Country.Name[pm2.5$Country.Name == "Venezuela, RB"] = "Venezuela"
pm2.5$Country.Name[pm2.5$Country.Name == "Korea, Dem. People\342\200\231s Rep."] = "North Korea"
pm2.5$Country.Name[pm2.5$Country.Name == "Gambia, The"] = "Gambia"
pm2.5$Country.Name[pm2.5$Country.Name == "Egypt, Arab Rep."] = "Egypt"
pm2.5$Country.Name[pm2.5$Country.Name == "Hong Kong SAR, China"] = "Hong Kong"
pm2.5$Country.Name[pm2.5$Country.Name == "Cote d'Ivoire"] = "C_te d'Ivoire"
pm2.5$Country.Name[pm2.5$Country.Name == "Macao SAR, China"] = "Macau"
pm2.5$Country.Name[pm2.5$Country.Name == "Russian Federation"] = "Russia"
pm2.5$Country.Name[pm2.5$Country.Name == "St. Vincent and the Grenadines"] = "Saint Vincent and the Grenadines"
pm2.5$Country.Name[pm2.5$Country.Name == "Iran, Islamic Rep."] = "Iran"
pm2.5$Country.Name[pm2.5$Country.Name == "Macedonia, FYR"] = "Macedonia [FYROM]"
pm2.5$Country.Name[pm2.5$Country.Name == "Myanmar"] = "Myanmar [Burma]"
pm2.5$Country.Name[pm2.5$Country.Name == "Congo, Dem. Rep."] = "Congo [DRC]"
pm2.5$Country.Name[pm2.5$Country.Name == "Congo, Rep."] = "Congo [Republic]"
pm2.5$Country.Name[pm2.5$Country.Name == "Cabo Verde"] = "Cape Verde"
pm2.5$Country.Name[pm2.5$Country.Name == "Micronesia, Fed. Sts."] = "Micronesia"
pm2.5$Country.Name[pm2.5$Country.Name == "Syrian Arab Republic"] = "Syria"
pm2.5$Country.Name[pm2.5$Country.Name == "St. Lucia"] = "Saint Lucia"
pm2.5$Country.Name[pm2.5$Country.Name == "Sao Tome and Principe"] = "S_o Tom_ and Pr_ncipe"
#pm2.5$Country.Name[pm2.5$Country.Name == "South Sudan"] = "Sudan"
pm2.5$Country.Name[pm2.5$Country.Name == "Brunei Darussalam"] = "Brunei"
pm2.5$Country.Name[pm2.5$Country.Name == "Kyrgyz Republic"] = "Kyrgyzstan"
pm2.5$Country.Name[pm2.5$Country.Name == "Slovak Republic"] = "Slovakia"
pm2.5$Country.Name[pm2.5$Country.Name == "West Bank and Gaza"] = "Gaza Strip"
pm2.5$Country.Name[pm2.5$Country.Name == "St. Kitts and Nevis"] = "Saint Kitts and Nevis"


pm2.5.reduced = pm2.5[pm2.5$Country.Name[1:217] %in% site$name,]

str(pm2.5.reduced)
reduced = data.frame(name = pm2.5.reduced[,1],
                     y2010 = as.numeric(pm2.5.reduced$y2010), 
                     y2011 = as.numeric(pm2.5.reduced$y2011),
                     y2012 = as.numeric(pm2.5.reduced$y2012),
                     y2013 = as.numeric(pm2.5.reduced$y2013),
                     y2014 = as.numeric(pm2.5.reduced$y2014),

                     e2010 = as.numeric(as.character(pm2.5.reduced$e2010)), 
                     e2011 = as.numeric(as.character(pm2.5.reduced$e2011)),
                     e2012 = as.numeric(as.character(pm2.5.reduced$e2012)),
                     e2013 = as.numeric(as.character(pm2.5.reduced$e2013)),
                     e2014 = as.numeric(as.character(pm2.5.reduced$e2014)),

                     f2010 = as.numeric(as.character(pm2.5.reduced$f2010)), 
                     f2011 = as.numeric(as.character(pm2.5.reduced$f2011)),
                     f2012 = as.numeric(as.character(pm2.5.reduced$f2012)),
                     f2013 = as.numeric(as.character(pm2.5.reduced$f2013)),
                     f2014 = as.numeric(as.character(pm2.5.reduced$f2014)),

                     r2010 = as.numeric(as.character(pm2.5.reduced$r2010)), 
                     r2011 = as.numeric(as.character(pm2.5.reduced$r2011)),
                     r2012 = as.numeric(as.character(pm2.5.reduced$r2012)),
                     r2013 = as.numeric(as.character(pm2.5.reduced$r2013)),
                     r2014 = as.numeric(as.character(pm2.5.reduced$r2014)),

                     u2010 = as.numeric(as.character(pm2.5.reduced$u2010)), 
                     u2011 = as.numeric(as.character(pm2.5.reduced$u2011)),
                     u2012 = as.numeric(as.character(pm2.5.reduced$u2012)),
                     u2013 = as.numeric(as.character(pm2.5.reduced$u2013)),
                     u2014 = as.numeric(as.character(pm2.5.reduced$u2014)),

                     forest2010 = as.numeric(as.character(pm2.5.reduced$forest2010)), 
                     forest2011 = as.numeric(as.character(pm2.5.reduced$forest2011)),
                     forest2012 = as.numeric(as.character(pm2.5.reduced$forest2012)),
                     forest2013 = as.numeric(as.character(pm2.5.reduced$forest2013)),
                     forest2014 = as.numeric(as.character(pm2.5.reduced$forest2014))
)
data = reduced[complete.cases(reduced),]
site[site$name %in% data$name,]$name

data = merge(x=data, y=site, key=name)

romania = which(data$name == "Romania")
data = data[-romania,]
dim(data)


data$e2010 = (data$e2010 - mean(data$e2010))/sd(data$e2010)
data$e2011 = (data$e2011 - mean(data$e2011))/sd(data$e2011)
data$e2012 = (data$e2012 - mean(data$e2012))/sd(data$e2012)
data$e2013 = (data$e2013 - mean(data$e2013))/sd(data$e2013)
data$e2014 = (data$e2014 - mean(data$e2014))/sd(data$e2014)

data$u2010 = (data$u2010 - mean(data$u2010))/sd(data$u2010)
data$u2011 = (data$u2011 - mean(data$u2011))/sd(data$u2011)
data$u2012 = (data$u2012 - mean(data$u2012))/sd(data$u2012)
data$u2013 = (data$u2013 - mean(data$u2013))/sd(data$u2013)
data$u2014 = (data$u2014 - mean(data$u2014))/sd(data$u2014)


library(maps)
map("world", fill=TRUE, col="white", bg="lightblue", ylim=c(-60, 90), mar=c(0,0,0,0))
points(data$lon,data$lat, col="red", pch=16, cex=(data$y2010)/(sum(data$y2010))*100)

map("world", fill=TRUE, col="white", bg="lightblue", ylim=c(-60, 90), mar=c(0,0,0,0))
points(data$lon,data$lat, col="red", pch=16, cex=(data$y2011)/(sum(data$y2011))*100)

map("world", fill=TRUE, col="white", bg="lightblue", ylim=c(-60, 90), mar=c(0,0,0,0))
points(data$lon,data$lat, col="red", pch=16, cex=(data$y2012)/(sum(data$y2012))*100)

map("world", fill=TRUE, col="white", bg="lightblue", ylim=c(-60, 90), mar=c(0,0,0,0))
points(data$lon,data$lat, col="red", pch=16, cex=(data$y2013)/(sum(data$y2013))*100)

map("world", fill=TRUE, col="white", bg="lightblue", ylim=c(-60, 90), mar=c(0,0,0,0))
points(data$lon,data$lat, col="red", pch=16, cex=(data$y2014)/(sum(data$y2014))*100)

map("world", fill=TRUE, col="white", bg="lightblue", ylim=c(-60, 90), mar=c(0,0,0,0))
points(data$lon,data$lat, col="red", pch=16, cex=(data$y2015)/(sum(data$y2015))*100)



#################################  Mapping  #################################


map("world", fill=TRUE, col="white", bg="lightblue", ylim=c(-60, 90), mar=c(0,0,0,0))
a=map("world", fill=TRUE, col="white", bg="lightblue", ylim=c(-60, 90), mar=c(0,0,0,0))

s1 <- sapply(strsplit(a$names, split=':', fixed=TRUE), function(x) (x[1]))
s1

unique(s1)
na.index = which(is.na(match(reduced$name, s1)))
reduced$name[na.index]
map.data = reduced
map.data$name = as.character(map.data$name)
map.data$name[c(47,44,45,115,133,191,200,201,162,207,176)] = 
  as.character(c("Ivory Coast","Democratic Republic of the Congo","Republic of Congo",
                 "Macedonia","Myanmar","Trinidad","UK","USA","Sao Tome and Principe","Virgin Islands, US",
                 "Saint Kitts"))

match(map.data$name, s1)
map.data$y2010


map.data$y2010_cut = as.numeric(cut(map.data$y2010, seq(0,130,by=10)))
map.data$y2011_cut = as.numeric(cut(map.data$y2011, seq(0,130,by=10)))
map.data$y2012_cut = as.numeric(cut(map.data$y2012, seq(0,130,by=10)))
map.data$y2013_cut = as.numeric(cut(map.data$y2013, seq(0,130,by=10)))
map.data$y2014_cut = as.numeric(cut(map.data$y2014, seq(0,130,by=10)))

map.data$y2010_cut[match(s1, map.data$name)]
colfunc <- colorRampPalette(c("white", "red"))
color.red = colfunc(13)
map.data$y2010_cut = color.red[map.data$y2010_cut]
map.data$y2011_cut = color.red[map.data$y2011_cut]
map.data$y2012_cut = color.red[map.data$y2012_cut]
map.data$y2013_cut = color.red[map.data$y2013_cut]
map.data$y2014_cut = color.red[map.data$y2014_cut]
leg.txt <- c("0-10", "10-20", "20-30", "30-40", "40-50",
             "50-60", "60-70", "70-80", "80-90", "90-100",
             "100-110", "110-120", "120-130")

s2 = match(s1, map.data$name)
s10 = map.data$y2010_cut[s2]
s11 = map.data$y2011_cut[s2]
s12 = map.data$y2012_cut[s2]
s13 = map.data$y2013_cut[s2]
s14 = map.data$y2014_cut[s2]


pdf('pm25_2010.pdf')
par(xpd=TRUE)
map("world", main='PM2.5 of 2010',fill=TRUE, col=s10, bg="lightblue", ylim=c(-60, 90), mar=c(0,0,0,0))
legend("bottom", bg="white",  leg.txt, horiz = TRUE, fill = color.red, cex=.45, inset=-.13)
dev.off()

pdf('pm25_2011.pdf')
par(xpd=TRUE)
map("world", main='PM2.5 of 2010',fill=TRUE, col=s11, bg="lightblue", ylim=c(-60, 90), mar=c(0,0,0,0))
legend("bottom", bg="white",  leg.txt, horiz = TRUE, fill = color.red, cex=.45, inset=-.13)
dev.off()

pdf('pm25_2012.pdf')
par(xpd=TRUE)
map("world", main='PM2.5 of 2010',fill=TRUE, col=s12, bg="lightblue", ylim=c(-60, 90), mar=c(0,0,0,0))
legend("bottom", bg="white",  leg.txt, horiz = TRUE, fill = color.red, cex=.45, inset=-.13)
dev.off()

pdf('pm25_2013.pdf')
par(xpd=TRUE)
map("world", main='PM2.5 of 2010',fill=TRUE, col=s13, bg="lightblue", ylim=c(-60, 90), mar=c(0,0,0,0))
legend("bottom", bg="white",  leg.txt, horiz = TRUE, fill = color.red, cex=.45, inset=-.13)
dev.off()

pdf('pm25_2014.pdf')
par(xpd=TRUE)
map("world", main='PM2.5 of 2010',fill=TRUE, col=s14, bg="lightblue", ylim=c(-60, 90), mar=c(0,0,0,0))
legend("bottom", bg="white",  leg.txt, horiz = TRUE, fill = color.red, cex=.45, inset=-.13)
dev.off()



##############################  Crwaling Borders ####################################


library(rvest)
url = "https://en.wikipedia.org/wiki/List_of_political_and_geographic_borders"
pop = url %>%
  read_html() %>%
  html_nodes(xpath = '//*[@id="mw-content-text"]/div/table[2]') %>%
  html_table(fill=TRUE)
st = pop[[1]]
#save(st, file = "boundary.Rdata")
str(st)
name = st$`Name of country`[-1]
boader = strsplit(st$Borders,'/')[-1]
boader.name = unlist(boader)

substrRight <- function(x, n){
  substr(x, nchar(x)-n+1, nchar(x))
}
substrLeft <- function(x){
  substr(x, 1, 1)
}

boader.name = ifelse( substrLeft(boader.name) == " ", gsub('^.', '', boader.name), boader.name)
boader.name = ifelse( substrRight(boader.name,1) == " ", gsub('.{1}$', '', boader.name), boader.name)
boader.name = ifelse( substrLeft(boader.name) == "*", gsub('^.', '', boader.name), boader.name)

unique(boader.name[-which(boader.name%in%data$name)])
notrightname = c("Macedonia","Congo, Democratic Republic of the", 
                 "Republic of the Congo", "Myanmar (Burma)", "Myanmar",  
                 "Bosnia Herzegovina",  "Ivory Coast",
                 "The Gambia", "Republic of Korea", "Democratic People's Republic of Korea", "Guinea Bissau") 

rightname = c("Macedonia [FYROM]", "Congo [DRC]",  "Congo [Republic]", "Myanmar [Burma]", "Myanmar [Burma]","Bosnia and Herzegovina", 
              "C_te d'Ivoire", "Gambia", "South Korea", "North Korea", "Guinea-Bissau")


for(i in 1:length(boader)){
  
  if(name[i] %in% notrightname){
    target1 = which(notrightname %in% name[i])
    name[i] = rightname[target1]
  } 
  
  
  if(length(boader[[i]])>0){
    
    for(j in 1:length(boader[[i]])){
      boader[[i]][j] = ifelse( substrLeft(boader[[i]][j]) == " ", gsub('^.', '', boader[[i]][j]), boader[[i]][j])
      boader[[i]][j] = ifelse( substrLeft(boader[[i]][j]) == "*", gsub('^.', '', boader[[i]][j]), boader[[i]][j])
      boader[[i]][j] = ifelse( substrRight(boader[[i]][j],1) == " ", gsub('.{1}$', '', boader[[i]][j]), boader[[i]][j])
      
      
      if(boader[[i]][j] %in% notrightname){
        target = which(notrightname %in% boader[[i]][j])
        boader[[i]][j] = rightname[target]
      }
      
      
    }
  } 
  
}

name.no = which(name %in% data$name)
name = name[name.no]
boader = boader[name.no]


## Serbia has "Bosnia and Herzegovina" as their neighbour, but "Bosnia and Herzegovina" does not have "Serbia" as their neighbor
if('Serbia' %in% name){
  BH = which(name == 'Serbia')
  boader[[BH]] = c(boader[[BH]], "Bosnia and Herzegovina")
}

data.name.no = which(data$name %in% name)
data = data[data.name.no,]
energy = energy[data.name.no,]
dim(data)


data$name == name

ind = c()
for(i in 1:length(name)){
  for(j in 1:length(data$name)){
    if(data$name[i] %in% name[j])
      ind = c(ind, j)
  }
}
ind
data$name == name[ind]
name = name[ind]
boader = boader[ind]

adjacent = matrix(0, dim(data)[1], dim(data)[1])
rownames(adjacent) = colnames(adjacent) = name

dim(adjacent)
for(i in 1:dim(adjacent)[1]){
  if(length(boader[[i]])>0) adjacent[i, colnames(adjacent)%in% boader[[i]]] = 1
}
no.neigh = which(rowSums(adjacent) + colSums(adjacent) == 0)

rownames(adjacent) = colnames(adjacent) = as.numeric(seq(dim(adjacent)[1]))
isSymmetric(adjacent)

for(i in 1:dim(data)[1]) {
  cat(sum(adjacent[i,] - adjacent[,i]), '\t', i, '\n')
  
}

library(igraph)
library(ade4)
adj = graph.adjacency(adjacent, mode='undirected')
adj.nb = neig2nb(neig(edges=matrix(as.numeric(get.edgelist(adj)),nc=2)))
adj.nb
str(adj.nb)

#####################

no.neigh.index=c()
for(i in 1:length(boader)){
  if(length(boader[[i]]) == 0) {
    no.neigh.index = c(no.neigh.index, i)
  }
}


data.yes = data[-no.neigh.index,]
energy.yes = energy[-no.neigh.index,]
name.yes = name[-no.neigh.index]
boader.yes.neigh = boader[-no.neigh.index]

## Cyprus removed since the neighbours of Cyprus are no contained data
if('Cyprus' %in% name){
  Cyp = which(name.yes == 'Cyprus')
  name.yes=name.yes[-Cyp]
  boader.yes.neigh = boader.yes.neigh[-Cyp]
  data.yes = data.yes[-Cyp,]
}

adjacent = matrix(0, length(name.yes), length(name.yes))
rownames(adjacent) = colnames(adjacent) = name.yes

dim(adjacent)
for(i in 1:dim(adjacent)[1]){
  if(length(boader.yes.neigh[[i]])>0) adjacent[i, colnames(adjacent)%in% boader.yes.neigh[[i]]] = 1
}
island = which(rowSums(adjacent) + colSums(adjacent) == 0)
adjacent = adjacent[-island, -island]
data.yes = data.yes[-island,]
rownames(adjacent) = colnames(adjacent) = as.numeric(seq(dim(adjacent)[1]))
isSymmetric(adjacent)


for(i in 1:dim(data.yes)[1]) {
  cat(sum(adjacent[i,] - adjacent[,i]), '\t', i, '\n')
}


adj.yes = graph.adjacency(adjacent, mode='undirected')
adj.yes.nb = neig2nb(neig(edges=matrix(as.numeric(get.edgelist(adj.yes)),nc=2)))
adj.yes.nb
str(adj.yes.nb)



########################### rain data ##################################

source("raincode.R")

data.yes.rain = data.frame(data.yes, rain_2010 = rain.2010[,1],
                           rain_2011 = rain.2011[,1],
                           rain_2012 = rain.2012[,1],
                           rain_2013 = rain.2013[,1],
                           rain_2014 = rain.2014[,1],
                           rain_2015 = rain.2015[,1])


data.yes.rain$rain_2010 = (data.yes.rain$rain_2010 - mean(data.yes.rain$rain_2010))/sd(data.yes.rain$rain_2010)
data.yes.rain$rain_2011 = (data.yes.rain$rain_2011 - mean(data.yes.rain$rain_2011))/sd(data.yes.rain$rain_2011)
data.yes.rain$rain_2012 = (data.yes.rain$rain_2012 - mean(data.yes.rain$rain_2012))/sd(data.yes.rain$rain_2012)
data.yes.rain$rain_2013 = (data.yes.rain$rain_2013 - mean(data.yes.rain$rain_2013))/sd(data.yes.rain$rain_2013)
data.yes.rain$rain_2014 = (data.yes.rain$rain_2014 - mean(data.yes.rain$rain_2014))/sd(data.yes.rain$rain_2014)


################################# Moran's I #########################################
library(spdep)

## the hypothesis of Randomization are all rejected.
moran.test(data.yes$y2010, nb2listw(adj.yes.nb, style="W"),randomisation=TRUE)
moran.test(data.yes$y2011, nb2listw(adj.yes.nb, style="W"),randomisation=TRUE)
moran.test(data.yes$y2012, nb2listw(adj.yes.nb, style="W"),randomisation=TRUE)
moran.test(data.yes$y2013, nb2listw(adj.yes.nb, style="W"),randomisation=TRUE)
moran.test(data.yes$y2014, nb2listw(adj.yes.nb, style="W"),randomisation=TRUE)

## the hypothesis of Normality are all rejected.
moran.test(data.yes$y2010, nb2listw(adj.yes.nb, style="W"),randomisation=FALSE)
moran.test(data.yes$y2011, nb2listw(adj.yes.nb, style="W"),randomisation=FALSE)
moran.test(data.yes$y2012, nb2listw(adj.yes.nb, style="W"),randomisation=FALSE)
moran.test(data.yes$y2013, nb2listw(adj.yes.nb, style="W"),randomisation=FALSE)
moran.test(data.yes$y2014, nb2listw(adj.yes.nb, style="W"),randomisation=FALSE)



################################# Modeling fitting SAR #########################################

y10 = spautolm(y2010 ~ e2010 + f2010 + r2010 + u2010 + rain_2010 + forest2010, data=data.yes.rain, listw=nb2listw(adj.yes.nb, style="W"))
y11 = spautolm(y2011 ~ e2011 + f2011 + r2011 + u2011 + rain_2011 + forest2011, data=data.yes.rain, listw=nb2listw(adj.yes.nb, style="W"))
y12 = spautolm(y2012 ~ e2012 + f2012 + r2012 + u2012 + rain_2012 + forest2012, data=data.yes.rain, listw=nb2listw(adj.yes.nb, style="W"))
y13 = spautolm(y2013 ~ e2013 + f2013 + r2013 + u2013 + rain_2013 + forest2013, data=data.yes.rain, listw=nb2listw(adj.yes.nb, style="W"))
y14 = spautolm(y2014 ~ e2014 + f2014 + r2014 + u2014 + rain_2014 + forest2014, data=data.yes.rain, listw=nb2listw(adj.yes.nb, style="W"))

(summ10 = summary(y10))
(summ11 = summary(y11))
(summ12 = summary(y12))
(summ13 = summary(y13))
(summ14 = summary(y14))

y10fit = y10$fit$fitted.values
y11fit = y11$fit$fitted.values
y12fit = y12$fit$fitted.values
y13fit = y13$fit$fitted.values
y14fit = y14$fit$fitted.values


sar.error = c(sum((data.yes$y2010 - y10fit)^2),
              sum((data.yes$y2011 - y11fit)^2),
              sum((data.yes$y2012 - y12fit)^2),
              sum((data.yes$y2013 - y13fit)^2),
              sum((data.yes$y2014 - y14fit)^2))
sqrt(sar.error)


library(xtable)

print.xtable(xtable(summ10), type="latex", file="summ10.tex")
print.xtable(xtable(summ11), type="latex", file="summ11.tex")
print.xtable(xtable(summ12), type="latex", file="summ12.tex")
print.xtable(xtable(summ13), type="latex", file="summ13.tex")
print.xtable(xtable(summ14), type="latex", file="summ14.tex")



################################# Modeling fitting CAR #########################################

y10car = spautolm(y2010 ~ e2010 + f2010 + r2010 + u2010 + rain_2010 + forest2010, data=data.yes.rain, family = "CAR", listw=nb2listw(adj.yes.nb, style="W"))
y11car = spautolm(y2011 ~ e2011 + f2011 + r2011 + u2011 + rain_2011 + forest2011, data=data.yes.rain, family = "CAR", listw=nb2listw(adj.yes.nb, style="W"))
y12car = spautolm(y2012 ~ e2012 + f2012 + r2012 + u2012 + rain_2012 + forest2012, data=data.yes.rain, family = "CAR", listw=nb2listw(adj.yes.nb, style="W"))
y13car = spautolm(y2013 ~ e2013 + f2013 + r2013 + u2013 + rain_2013 + forest2013, data=data.yes.rain, family = "CAR", listw=nb2listw(adj.yes.nb, style="W"))
y14car = spautolm(y2014 ~ e2014 + f2014 + r2014 + u2014 + rain_2014 + forest2014, data=data.yes.rain, family = "CAR", listw=nb2listw(adj.yes.nb, style="W"))


summ10 = summary(y10car)
summ11 = summary(y11car)
summ12 = summary(y12car)
summ13 = summary(y13car)
summ14 = summary(y14car)

print.xtable(xtable(summ10), type="latex", file="summ10car.tex")
print.xtable(xtable(summ11), type="latex", file="summ11car.tex")
print.xtable(xtable(summ12), type="latex", file="summ12car.tex")
print.xtable(xtable(summ13), type="latex", file="summ13car.tex")
print.xtable(xtable(summ14), type="latex", file="summ14car.tex")

data.yes.rain$r2014
data.yes.rain[c(24,77,99),]

summary(y11car)
summary(y10car)
summary(y12car)
summary(y13car)
summary(y14car)

y10carfit = y10car$fit$fitted.values
y11carfit = y11car$fit$fitted.values
y12carfit = y12car$fit$fitted.values
y13carfit = y13car$fit$fitted.values
y14carfit = y14car$fit$fitted.values


car.error = c(sum((data.yes$y2010 - y10carfit)^2),
              sum((data.yes$y2011 - y11carfit)^2),
              sum((data.yes$y2012 - y12carfit)^2),
              sum((data.yes$y2013 - y13carfit)^2),
              sum((data.yes$y2014 - y14carfit)^2))

sqrt(sar.error)
sqrt(car.error)

################################# Modeling fitting CAR+AR(1) #########################################

library(CARBayesST)

K = dim(data.yes.rain)[1]
N = 5
N.all = N * K
beta0 = 0
beta1 = beta2 = beta3 = beta4 = beta5 = beta6 = 3
p = 6

W = adjacent

rhos = rhot = runif(1)

#Q.W = 0.9 * (diag(apply(W, 2, sum)) - rhos*W) + 0.1 * diag(rep(1,K))
Q.W = (diag(apply(W, 2, sum)) - rhos*W)

solve(Q.W)
dist = matrix(rep(c(1,2,3,4,5), 5),5,5)
dist = sqrt((dist - t(dist))^2) + 1
library(geoR)
Sigma = matern(dist, phi=.1, kappa=.5)

var = kronecker(Q.W, solve(Sigma))
var[1,1]
inv.var = solve(var)
isSymmetric.matrix(inv.var)
phi.temp = mvrnorm(n=1, mu=rep(0,K), Sigma=inv.var[(1:K),(1:K)])
phi = phi.temp
for(i in 2:N){
  phi.temp2 = mvrnorm(n=1, mu=(rhot * phi.temp), Sigma=inv.var[((K*(i-1)+1):(K*i)),((K*(i-1)+1):(K*i))])
  phi.temp = phi.temp2
  phi = c(phi, phi.temp)
}
e = c(data.yes.rain$e2010, data.yes.rain$f2011, data.yes.rain$e2012, data.yes.rain$e2013, data.yes.rain$e2014)
f = c(data.yes.rain$f2010, data.yes.rain$f2011, data.yes.rain$f2012, data.yes.rain$f2013, data.yes.rain$f2014)
r = c(data.yes.rain$r2010, data.yes.rain$r2011, data.yes.rain$r2012, data.yes.rain$r2013, data.yes.rain$r2014)
u = c(data.yes.rain$u2010, data.yes.rain$u2011, data.yes.rain$u2012, data.yes.rain$u2013, data.yes.rain$u2014)
ra = c(data.yes.rain$rain_2010, data.yes.rain$rain_2011, data.yes.rain$rain_2012, data.yes.rain$rain_2013, data.yes.rain$rain_2014)
forst = c(data.yes.rain$forest2010, data.yes.rain$forest2011, data.yes.rain$forest2012, data.yes.rain$forest2013, data.yes.rain$forest2014)

xb = beta0 + e * beta1 + f * beta2 + r * beta3 + u * beta4 + ra * beta5 + forst * beta6 + phi

gamma = rnorm(n=N.all, mean=0, sd=0.001)

Lp = phi + gamma

y = c(data.yes$y2010, data.yes$y2011, data.yes$y2012, data.yes$y2013, data.yes$y2014)
st = ST.CARar(formula=y~Lp+e+f+r+u+ra+forst, family="gaussian", data=data.yes.rain, W=adjacent, burnin=10000,
              n.sample=1000000, thin=100)


pdf('trace.pdf')
plot(st$samples$beta)
dev.off()
fitted = st$fitted.values
sum((data.yes$y2010 - fitted)^2)
st.summ = st$summary.results
str(st)

print.xtable(xtable(st.summ), type="latex", file="stsumm.tex")


fitted = st$fitted.values
fitted.2010 = fitted[1:dim(data.yes)[1]]
fitted.2011 = fitted[(dim(data.yes)[1] + 1):(2*dim(data.yes)[1])]
fitted.2012 = fitted[(2*dim(data.yes)[1]+1):(3*dim(data.yes)[1])]
fitted.2013 = fitted[(3*dim(data.yes)[1]+1):(4*dim(data.yes)[1])]
fitted.2014 = fitted[(4*dim(data.yes)[1]+1):(5*dim(data.yes)[1])]


mcar.error = c(sum((data.yes$y2010 - fitted.2010)^2),
               sum((data.yes$y2011 - fitted.2011)^2),
               sum((data.yes$y2012 - fitted.2012)^2),
               sum((data.yes$y2013 - fitted.2013)^2),
               sum((data.yes$y2014 - fitted.2014)^2))


sqrt(mcar.error)


