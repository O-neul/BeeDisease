

rain.1_30 = read.csv('pr5_1991_2015 (1-30).csv', header=T) 
rain.31_60 = read.csv('pr5_1991_2015 (31-60).csv', header=T) 
rain.61_90 = read.csv('pr5_1991_2015 (61-90 no romania).csv', header=T) 
rain.91_109 = read.csv('pr5_1991_2015 (91-109).csv', header=T) 

rain = rbind(rain.1_30, rain.31_60, rain.61_90, rain.91_109)

rain.mean = rain[seq(1,dim(rain)[1], by=12),]
for(i in 1:(dim(rain)[1]/12)){
    rain.mean[i,1] = mean(rain[( (12*(i-1)+1):(12*(i-1)+12) ),1])
}

rain.mean[20:25,]
a = seq(19,24)
b = seq(1,dim(rain.mean)[1]/25)
b = 25*(b-1) + 1

c=c()
for(i in 1:length(b)){
  c = c(c, b[i] + a)
}
rain = rain.mean[c,c(1,2,4)]
seq.2010 = seq(1, dim(rain)[1], by=6)
seq.2011 = seq(2, dim(rain)[1]+1, by=6)
seq.2012 = seq(3, dim(rain)[1]+2, by=6)
seq.2013 = seq(4, dim(rain)[1]+3, by=6)
seq.2014 = seq(5, dim(rain)[1]+4, by=6)
seq.2015 = seq(6, dim(rain)[1]+5, by=6)

rain.2010 = rain[seq.2010,]
rain.2011 = rain[seq.2011,]
rain.2012 = rain[seq.2012,]
rain.2013 = rain[seq.2013,]
rain.2014 = rain[seq.2014,]
rain.2015 = rain[seq.2015,]
l = seq(1,dim(rain.2013)[1])

cog = l[which(rain.2013[,3] == "COG")]
zar = l[which(rain.2013[,3] == "ZAR")]

temp = rain.2010[cog,]
rain.2010[cog,] = rain.2010[zar,]
rain.2010[zar,] = temp

temp = rain.2011[cog,]
rain.2011[cog,] = rain.2011[zar,]
rain.2011[zar,] = temp

temp = rain.2012[cog,]
rain.2012[cog,] = rain.2012[zar,]
rain.2012[zar,] = temp

temp = rain.2013[cog,]
rain.2013[cog,] = rain.2013[zar,]
rain.2013[zar,] = temp
3
temp = rain.2014[cog,]
rain.2014[cog,] = rain.2014[zar,]
rain.2014[zar,] = temp

temp = rain.2015[cog,]
rain.2015[cog,] = rain.2015[zar,]
rain.2015[zar,] = temp


khm = l[which(rain.2013[,3] == "KHM")]
civ = l[which(rain.2013[,3] == "CIV")]

temp = rain.2010[khm:(civ-1),]
rain.2010[khm,] = rain.2010[civ,]
rain.2010[(khm+1):civ,] = temp

temp = rain.2011[khm:(civ-1),]
rain.2011[khm,] = rain.2011[civ,]
rain.2011[(khm+1):civ,] = temp


temp = rain.2012[khm:(civ-1),]
rain.2012[khm,] = rain.2012[civ,]
rain.2012[(khm+1):civ,] = temp


temp = rain.2013[khm:(civ-1),]
rain.2013[khm,] = rain.2013[civ,]
rain.2013[(khm+1):civ,] = temp

temp = rain.2014[khm:(civ-1),]
rain.2014[khm,] = rain.2014[civ,]
rain.2014[(khm+1):civ,] = temp


temp = rain.2015[khm:(civ-1),]
rain.2015[khm,] = rain.2015[civ,]
rain.2015[(khm+1):civ,] = temp

